function [A,E,R]=harmonyratio(tvec,rb,bazb,psint,n)
phib=0;
phie=180; % search till 180 rather than 360 since it's 180-period
phiint=4;
phi=phib:phiint:phie;

%search range of deltat
deltatb=0;
deltate=1; % 1s is enough for crustal anisotropy
deltatint=0.04;
deltat=deltatb:deltatint:deltate;

fr0all=rb(psint,:);
fr0=harmony(tvec,rb,bazb,0,0,psint,n);
eventn=size(rb,2);
for i=1:length(phi) 
        tic;
    parfor j=1:length(deltat)
      
        fr=harmony(tvec,rb,bazb,phi(i),deltat(j),psint,n);
        A(i,j)=max(fr)/max(fr0);
        E(i,j)=sum(fr.^2)/sum(fr0.^2);
        R(i,j)=sum(sum((repmat(fr,1,eventn)-fr0all).^2,1))./...
            sum(sum((repmat(fr0,1,eventn)-fr0all).^2,1));
        
    end
toc;
end
end

% harmony sanalysis
function fr=harmony(tvec,r,theta,phi,deltat,psint,n)
% n - harmonic order

%judge the input theta is rad system or angle system
if max(theta)>2*pi
theta=theta/180*pi;
end
for j=1:length(theta)
            rj(:,j)=interp1(tvec,r(:,j),tvec-deltat/2*cos(n*theta(j)+phi),'linear');
end 
            rj(isnan(rj))=0;           
fr=sum(rj(psint,:),2);
end