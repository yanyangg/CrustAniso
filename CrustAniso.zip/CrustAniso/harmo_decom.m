function [A0,A1,A2,s]=harmo_decom(baz,R,T)
% a function used to compute harmonic decomposition
% Input:
% R - radial RFs, size(RF)=npts*(#traces)
% T - transverse RFs, size(R)=size(T)
% baz - back azimuth, length(baz)=#traces
% Output:
% harmonic series for cos(k*phi)
% A0 - k=0
% A1 - k=1
% A2 - k=2
% s - uncertainty, reference: Shen weisen,2013GJI,formula (A2)
% Usage: IRLS.m
% Reference: Zhen Liu, Jeffrey Park, Danny M. Rye, Tectonophysics, 2015
% section 2.2.2

% initialize model ABCDE
npts=size(R,1);
nbaz=length(baz);
ABCDE=zeros(5,npts);

baz=baz./180*pi;% angular from degree to rad
if size(R,2)~=nbaz
    error('input the matrix with right number of traces!');
end

if nargin==2
    % compute G matrix
    for i=1:nbaz
        G(i,:)=[1,cos(baz(i)),sin(baz(i)),cos(2*baz(i)),sin(2*baz(i))];
    end
    for i=1:npts
        [ABCDE(:,i),~]=IRLS(R(i,:)',G,100);
    end
elseif nargin==3
    % compute G matrix
    for i=1:nbaz
        G(i,:)=[1,cos(baz(i)),sin(baz(i)),cos(2*baz(i)),sin(2*baz(i))];
    end
    for i=1:nbaz
        G(i+nbaz,:)=[0,cos(baz(i)+pi/2),sin(baz(i)+pi/2),cos(2*baz(i)+pi/4),sin(2*baz(i)+pi/4)];
    end
    for i=1:npts
        [ABCDE(:,i),~,iternum]=IRLS([R(i,:)';T(i,:)'],G,100);
    end
else
    error('check input!');
end
A0=repmat(ABCDE(1,:)',1,nbaz); 
A1=ABCDE(2,:)'*cos(baz)+ABCDE(3,:)'*sin(baz);
A2=ABCDE(4,:)'*cos(2*baz)+ABCDE(5,:)'*sin(2*baz);
s=(sum((R-A0-A1-A2).^2,2)/nbaz).^(1/2);