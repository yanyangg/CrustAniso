%% iteractively reweighted least squares (IRLS) method )(inversion homework)
% [m,r]=IRLS(d,G,iternum)
% input: data matrix d, G matrix G & iteractive times iternum
% output: model m & residual r
function [m,r,realiternum]=IRLS(d,G,iternum)
m0=inv(G'*G)*G'*d;
m=m0;
% a small positive number:e
e=10^-15;
mm(:,1)=m0;
for i=1:iternum
    r=d-G*m;
    R=diag(min(1./abs(r),1/e),0);
    mm(:,i+1)=inv(G'*R*G)*G'*R*d;
    if norm(mm(:,i+1)-mm(:,i))/norm(mm(:,i+1))<0.01
        break;
    end
end
m=mm(:,end);
realiternum=i;
