%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%    You may have to change:1.matdir                                  %%%
%%%                           2.staindex                                %%%                               %%%
%%%                           3.phiint                                  %%%
%%%    This step may be very slow if a lot of stations need to be       %%%
%%%    computed, try parfor instead of for if necessary.                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;

matdir='./sta_mat';

[staindex,net]=textread('./stalist.txt','%s %s');

n_parpool=4; % use 4 cores to parallel 

% Ps phase time window
ps_time=5;% Ps arrival time close to 5s (0s at P arrival)
ps_win=1;% [-1,1]s of Ps arrival

% stack as each 5 degree back azimuth bin
binsize=5;

    
for ii=1:size(staindex,1)
    load(fullfile(matdir,[staindex{ii},'.mat']));
    psint(1)=find(abs(tvec-(ps_time-ps_win))<1e-4);
    psint(2)=find(abs(tvec-(ps_time+ps_win))<1e-4);
    psint=psint(1):psint(2);
    
    [rb,tb,bazb,rfnum]=rfbin(rmc,tmc,baz,5);
for k=1:8
[A,E,R]=harmonyratio(tvec,rb,bazb,psint,k);
AA(k)=max(max(A));
EE(k)=max(max(E));
RR(k)=1/min(min(R));
end
save(fullfile(matdir,[staindex{ii},'harmo.mat']),'AA','EE','RR');
end



